import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor

# 1️⃣ Load dataset
df = pd.read_csv("data/user_nutrition.csv")
print("✅ Dataset loaded")

# 2️⃣ Encode activity level
activity_encoder = LabelEncoder()
df["activity_encoded"] = activity_encoder.fit_transform(df["activity_level"])

# 3️⃣ Features & target
X = df[["age", "height_cm", "weight_kg", "activity_encoded"]]
y = df["daily_calories"]

# 4️⃣ Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# -----------------------------
# 5️⃣ Linear Regression Model
# -----------------------------
linear_model = LinearRegression()
linear_model.fit(X_train, y_train)

joblib.dump(linear_model, "ml_model/linear_model.pkl")
print("✅ Linear Regression model saved")

# -----------------------------
# 6️⃣ Random Forest Model
# -----------------------------
rf_model = RandomForestRegressor(
    n_estimators=200,
    random_state=42
)
rf_model.fit(X_train, y_train)

joblib.dump(rf_model, "ml_model/rf_model.pkl")
print("✅ Random Forest model saved")

# -----------------------------
# 7️⃣ Save encoder
# -----------------------------
joblib.dump(activity_encoder, "ml_model/activity_encoder.pkl")
print("✅ Activity encoder saved")
