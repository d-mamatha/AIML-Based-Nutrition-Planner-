import joblib
import os

BASE_DIR = os.path.dirname(os.path.dirname(__file__))
MODEL_DIR = os.path.join(BASE_DIR, "ml_model")

rf_model = joblib.load(os.path.join(MODEL_DIR, "rf_model.pkl"))
activity_encoder = joblib.load(os.path.join(MODEL_DIR, "activity_encoder.pkl"))

def predict_daily_calories(age, height, weight, activity_level):
    # normalize input
    activity_level = activity_level.strip().lower()

    # normalize encoder classes
    classes = [c.lower() for c in activity_encoder.classes_]

    # fallback to first class if mismatch
    if activity_level not in classes:
        encoded = activity_encoder.transform([activity_encoder.classes_[0]])[0]
    else:
        encoded = activity_encoder.transform(
            [activity_encoder.classes_[classes.index(activity_level)]]
        )[0]

    X = [[age, height, weight, encoded]]
    prediction = rf_model.predict(X)[0]

    return round(float(prediction), 2)
