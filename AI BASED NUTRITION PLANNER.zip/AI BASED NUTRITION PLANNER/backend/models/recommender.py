import pandas as pd
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CSV_PATH = os.path.join(BASE_DIR, "data", "food_dataset.csv")

df = pd.read_csv(CSV_PATH)

df.columns = df.columns.str.strip().str.lower()
df["calories"] = pd.to_numeric(df["calories"], errors="coerce")
df["allergy"] = df["allergy"].fillna("none").str.lower()
df["cuisine"] = df["cuisine"].str.lower()
df = df.dropna(subset=["calories"])


def pick(df, meal, target):
    m = df[df["meal_type"].str.lower() == meal.lower()]
    if m.empty:
        return {"food": "No food", "calories": target}
    m = m.copy()
    m["d"] = abs(m["calories"] - target)
    r = m.sort_values("d").iloc[0]
    return {"food": r["food_name"], "calories": int(r["calories"])}


def recommend_meals(total_calories, allergy, cuisine):
    d = df.copy()

    if allergy.lower() != "none":
        d = d[d["allergy"] != allergy.lower()]

    d = d[d["cuisine"] == cuisine.lower()]

    b = int(total_calories * 0.25)
    l = int(total_calories * 0.40)
    di = total_calories - b - l

    return {
        "Breakfast": pick(d, "Breakfast", b),
        "Lunch": pick(d, "Lunch", l),
        "Dinner": pick(d, "Dinner", di)
    }
