from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import pandas as pd

# --------------------------------------------------
# App initialization
# --------------------------------------------------
app = FastAPI(title="AI/ML Based Nutrition Planner")

# ✅ CORS (for frontend connection)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],   # frontend allowed
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --------------------------------------------------
# Input Schema
# --------------------------------------------------
class UserInput(BaseModel):
    name: str
    email: str
    age: int
    height: float   # cm
    weight: float   # kg
    activity_level: str
    allergy: str
    cuisine: str


# --------------------------------------------------
# Helper Functions
# --------------------------------------------------
def calculate_bmi(weight, height_cm):
    height_m = height_cm / 100
    return round(weight / (height_m ** 2), 2)


def bmi_category(bmi_value):
    if bmi_value < 18.5:
        return "Underweight"
    elif bmi_value < 25:
        return "Normal"
    elif bmi_value < 30:
        return "Overweight"
    else:
        return "Obese"


def calculate_bmr(weight, height_cm, age):
    # Mifflin-St Jeor (Female)
    return 10 * weight + 6.25 * height_cm - 5 * age - 161


def activity_multiplier(level):
    levels = {
        "sedentary": 1.2,
        "lightly active": 1.375,
        "moderately active": 1.55,
        "very active": 1.725
    }
    return levels[level.lower()]


# --------------------------------------------------
# API Endpoint
# --------------------------------------------------
@app.post("/predict")
def predict(user: UserInput):
    try:
        # -------- Health Metrics --------
        bmi_value = calculate_bmi(user.weight, user.height)
        bmi_type = bmi_category(bmi_value)

        bmr_value = calculate_bmr(user.weight, user.height, user.age)
        daily_calories = int(bmr_value * activity_multiplier(user.activity_level))

        # -------- Load Dataset --------
        df = pd.read_csv("data/food_dataset.csv")
        df.columns = df.columns.str.lower().str.strip()

        df["meal_type"] = df["meal_type"].fillna("").str.lower()
        df["cuisine"] = df["cuisine"].fillna("").str.lower()
        df["allergy"] = df["allergy"].fillna("none").str.lower()
        df["calories"] = pd.to_numeric(df["calories"], errors="coerce")

        df = df.dropna(subset=["calories"])

        # -------- Filter by Cuisine & Allergy --------
        filtered = df[
            (df["cuisine"] == user.cuisine.lower()) &
            (
                (df["allergy"] == "none") |
                (~df["allergy"].str.contains(user.allergy.lower(), na=False))
            )
        ]

        if filtered.empty:
            raise HTTPException(status_code=400, detail="No food found")

        # -------- Pick Breakfast & Lunch --------
        breakfast = filtered[filtered["meal_type"] == "breakfast"].sample(1).iloc[0]
        lunch = filtered[filtered["meal_type"] == "lunch"].sample(1).iloc[0]

        # -------- Adjust Dinner Calories (KEY LOGIC) --------
        remaining_calories = daily_calories - (
            int(breakfast.calories) + int(lunch.calories)
        )

        if remaining_calories <= 0:
            remaining_calories = int(daily_calories * 0.3)

        dinner = filtered[filtered["meal_type"] == "dinner"].sample(1).iloc[0]

        # -------- Response --------
        return {
            "Name": user.name,
            "Email": user.email,
            "BMI": bmi_value,
            "BMI_Type": bmi_type,
            "BMR": round(bmr_value, 2),
            "Daily_Calories": daily_calories,
            "Meals": {
                "Breakfast": {
                    "food_name": breakfast.food_name,
                    "calories": int(breakfast.calories),
                    "meal_type": "breakfast"
                },
                "Lunch": {
                    "food_name": lunch.food_name,
                    "calories": int(lunch.calories),
                    "meal_type": "lunch"
                },
                "Dinner": {
                    "food_name": dinner.food_name,
                    "calories": remaining_calories,
                    "meal_type": "dinner"
                }
            }
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
