const API = "http://127.0.0.1:8000";

// Load cuisines
window.onload = () => {
  fetch(`${API}/cuisines`)
    .then(res => res.json())
    .then(data => {
      const select = document.getElementById("cuisine");
      select.innerHTML = "";
      data.cuisines.forEach(c => {
        let opt = document.createElement("option");
        opt.value = c;
        opt.textContent = c;
        select.appendChild(opt);
      });
    });
};

function submitForm() {
  const payload = {
    name: name.value,
    email: email.value,
    age: Number(age.value),
    height: Number(height.value),
    weight: Number(weight.value),
    activity_level: activity.value,
    allergy: allergy.value,
    cuisine: cuisine.value
  };

  fetch(`${API}/predict`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  })
  .then(res => res.json())
  .then(data => {
    document.getElementById("output").textContent =
      JSON.stringify(data, null, 2);
  });
}
